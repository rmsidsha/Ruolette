package gui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;


public class RotateImage extends JPanel implements Runnable{
	   
	   //String path = "C:\\Users\\Administrator\\Desktop\\img\\5th.jpg";
	   JPanel panel;
	   JLabel label;
	   String path;  //���� ���
	   
	   public RotateImage() {}
	   public RotateImage(String path) throws IOException {
		   panel = new JPanel();
		   label = new JLabel();
		   this.path = path;  //���� ��� 
	   }
	   
		@Override
		public void run() {		
			while(true) {
				int time = (int)(Math.random()*1000);
				try {
					 for(int i=0; i<=time; i+=1) {  //i�� ���ư��� �ӵ�
						   BufferedImage oldImage = ImageIO.read(new FileInputStream(path));  
						   BufferedImage newImage = new BufferedImage(oldImage.getHeight(), oldImage.getWidth(), oldImage.getType());
						   Graphics2D graphics = (Graphics2D) newImage.getGraphics();
						   graphics.rotate(Math.toRadians(i), newImage.getWidth() / 2, newImage.getHeight() / 2);
						   graphics.translate((newImage.getWidth() - oldImage.getWidth()) / 2, (newImage.getHeight() - oldImage.getHeight()) / 2);
						   graphics.drawImage(oldImage, 0, 0, oldImage.getWidth(), oldImage.getHeight(), null);			   
						   ImageIcon icon = new ImageIcon(newImage);
						   label.setIcon(icon);
						   add(label);
						   setVisible(true);
						   System.gc();
					   }
				}catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		/*private void RotateImage() throws IOException {
			RotateImage r = new RotateImage();
		}*/
}

