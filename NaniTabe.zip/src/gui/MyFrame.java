package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;

public class MyFrame extends JFrame {
	
	private	Roulette p_one = null;
	private Calculator p_two = null;
	private Information p_three = null;
	private Record p_four = null;
	private JPanel nPanel, ePanel, wPanel, sPanel;
	
	public MyFrame() {
		setTitle("frame test");	
		
		p_one = new Roulette();
		p_two = new Calculator(this);
		p_three = new Information(this);
		p_four = new Record(this);
		nPanel = new JPanel();
		ePanel = new JPanel();
		wPanel = new JPanel();
		sPanel = new JPanel();
		
		JTabbedPane jtab = new JTabbedPane(JTabbedPane.BOTTOM);
		
//		jtab.setUI(new CustomTabbedPaneUI());
//		jtab.setUI();
		jtab.addTab("Roulette!", p_one);
		jtab.addTab("Information!", p_two);
		jtab.addTab("Calculator!", p_three);
		jtab.addTab("Record!", p_four);
		jtab.setForeground(Color.WHITE);
		jtab.setBackground(Color.black);
//        jtab.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.blue));
        jtab.setFont(new Font("gothic", Font.PLAIN, 18));
//        jtab.setBorder(BorderFactory.createTitledBorder("NaniTabe"));

        
		add(jtab);
		
		JButton jb = new JButton("start");
		nPanel.setLayout(null);
		
		JLabel label = new JLabel("NaniTabe!");
//		label.setSize(130,20);
//		label.setLocation(0,0);
		label.setBounds(175, 24, 400, 35);

		label.setFont(new Font("serif", Font.BOLD,24));
		nPanel.setPreferredSize(new Dimension(160, 70));
		nPanel.add(label);
		
//		add(nPanel, BorderLayout.NORTH);
//		add(ePanel, BorderLayout.EAST);
		add(jtab, BorderLayout.CENTER);
//		add(wPanel, BorderLayout.WEST);
//		add(sPanel, BorderLayout.SOUTH)
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(550, 987);
//		setResizable(false);

		setVisible(true);
	}

}
